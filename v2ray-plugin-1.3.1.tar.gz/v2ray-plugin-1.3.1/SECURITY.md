# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| latest  | :white_check_mark: |
| else    | :x:                |

## Reporting a Vulnerability

Please email to repo owner: Max Lv
