#include <ncurses.h>

int main(int argc, char *argv[])
{
	initscr();

	return 0;
}
