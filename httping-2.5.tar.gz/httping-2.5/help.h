#define SWITCHES_COLUMN_WIDTH	24

void new_version_alert(void);
void version(void);
void help_long(void);
void usage(const char *me);
