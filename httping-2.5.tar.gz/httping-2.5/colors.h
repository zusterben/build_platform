extern const char *c_error;
extern const char *c_normal;
extern const char *c_very_normal;
extern const char *c_red;
extern const char *c_blue;
extern const char *c_green;
extern const char *c_yellow;
extern const char *c_magenta;
extern const char *c_cyan;
extern const char *c_white;
extern const char *c_bright;

#define COLOR_ESCAPE "\001"

void set_colors(char nc);
